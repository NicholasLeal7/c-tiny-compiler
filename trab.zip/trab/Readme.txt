# Inicialmente, decidimos que o arquivo fonte de entrada deve obter no máximo até 10.000 caracteres para evitar problemas de 
overflow de buffer. Acreditamos que essa quantidade é suficiente para testar o programa.

# Para suprir a necessidade de no máximo 15 caracteres em um IDENTIFICADOR, 
optamos por atribuir uma variável `maximo_char` e retornar erro instantaneamente na máquina de estados caso a quantidade 
ultrapasse 15.

# Para implementar a máquina de estados dos identificadores, usamos a mesma base do miniléxico feito em vídeo-aula e 
criamos AFDs para construir as máquinas de estados de `charconst` e `intconst`.

# Quando estávamos implementando o reconhecimento dos operadores como `+ - > <`... e sinais como `() , ; {}`, 
resolvemos criar uma função para reconhecer operadores e sinais, pois o código estava virando uma torre gigante 
de `else if`. Tomamos essa decisão porque percebemos que teríamos que criar uma função para reconhecer palavras 
reservadas, então acabou sendo apropriado.

# Na parte de atribuir tamanho ao vetor que será responsável por armazenar o `intconst`, 
decidimos deixar o tamanho de 8 caracteres, pois `0xFFFFFFFF` é o maior número possível na notação hexadecimal com 
um tipo inteiro de 32 bits. Assim, nossa função que reconhece números retorna ERRO caso tenha mais de 8 caracteres + 2 (`0x`).

# O analisador léxico foi finalizado com a criação das funções que reconhecem as palavras reservadas e a 
ue reconhece os comentários e adapta suas linhas, sem muitas complicações.

# A análise sintática foi concluída sem muitas ressalvas, porém nos baseamos no enunciado desatualizado erroneamente 
e perdemos um bom tempo tentando encontrar lógica na gramática. Quando abrimos o Moodle para enviar uma mensagem 
questionando, vimos que havia um aviso informando que a gramática recebeu ajustes, aí sim funcionou de verdade.

# Na hora de contar as linhas, em `obter_atomo()`, a função `reconhecer_comentarios()` possui uma 
individualidade. Todos os átomos reconhecidos podem ter sua respectiva linha atribuída exatamente antes 
de retornarmos o `TInfoAtomo`, pois nenhuma função, com exceção do `reconhece_comentarios()`, modifica a 
variável global de linhas. Portanto, a atribuição da linha em que o comentário se iniciou é feita dentro da função de 
comentários e, caso estejamos analisando um comentário, a parte de atualização antes do retorno deve ser ignorada.